import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.XmlUtil;
import groovy.util.*;

def Message processData(Message message) {
    def body = message.getBody(java.lang.String);
    map = message.getProperties();
    def Indicator = map.get("SpecialIndicator");
    def SalesOrder = map.get("SalesOrder");
    def SalesOrderItem = map.get("SalesOrderItem");
    def root = new XmlParser().parseText(body)
    root.ProcOrdConf2Type.to_ProcOrdConfMatlDocItm.ProcOrdConfMatlDocItmType.each { ProcOrdConfMatlDocItmType ->
        ProcOrdConfMatlDocItmType.appendNode("InventorySpecialStockType", Indicator)
        ProcOrdConfMatlDocItmType.appendNode("SalesOrder", SalesOrder)
        ProcOrdConfMatlDocItmType.appendNode("SalesOrderItem", SalesOrderItem)
    }
    message.setBody(XmlUtil.serialize(root));
    return message;
}
